Note that you have to install the library before you can build this example,
which is done by running `cmake --build . --config Release --target install`
(noted as optional in the library [README](../../README.md#building)).
